# Getting Started with the App

This document provides a step-by-step tutorial on how to get the App going and how to use it.

## Install the App

To install the App, please follow the instructions detailed in the [Installation Guide](../admin/install.md).

## First steps with the App

!!! warning "Developer Note - Remove Me!"
    What (with screenshots preferably) does it look like to perform the simplest workflow within the App once installed?

## What are the next steps?

!!! warning "Developer Note - Remove Me!"
    After taking the first steps, what else could the users look at doing.

You can check out the [Use Cases](app_use_cases.md) section for more examples.
