# Using the App

This document describes common use-cases and scenarios for this App.

## General Usage

## Use-cases and common workflows

## Screenshots

!!! warning "Developer Note - Remove Me!"
    Ideally captures every view exposed by the App. Should include a relevant dataset.
