# External Interactions

This document describes external dependencies and prerequisites for this App to operate, including system requirements, API endpoints, interconnection or integrations to other applications or services, and similar topics.

!!! warning "Developer Note - Remove Me!"
    Optional page, remove if not applicable.

## External System Integrations

### From the App to Other Systems

### From Other Systems to the App

## Nautobot REST API endpoints

!!! warning "Developer Note - Remove Me!"
    API documentation in this doc - including python request examples, curl examples, postman collections referred etc.
