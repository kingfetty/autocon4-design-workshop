# Compatibility Matrix

!!! warning "Developer Note - Remove Me!"
    Explain how the release models of the app and of Nautobot work together, how releases are supported, how features and older releases are deprecated etc.

| Containerlab Version | Nautobot First Support Version | Nautobot Last Support Version |
| ------------- | -------------------- | ------------- |
| 1.0.X         | 2.3.0                | 2.99.99        |
