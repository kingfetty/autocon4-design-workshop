# Code Reference

Auto-generated code reference documentation from docstrings.

!!! warning "Developer Note - Remove Me!"
    Uses [mkdocstrings](https://mkdocstrings.github.io/) syntax to auto-generate code documentation from docstrings. Two example pages are provided ([api](api.md) and [package](package.md)), add new stubs for each module or package that you think has relevant documentation.
