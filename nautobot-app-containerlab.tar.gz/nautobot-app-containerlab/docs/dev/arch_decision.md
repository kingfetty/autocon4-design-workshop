# Architecture Decision Records

The intention is to document deviations from a standard Model View Controller (MVC) design.

!!! warning "Developer Note - Remove Me!"
    Optional page, remove if not applicable.
    For examples see [Golden Config](https://github.com/nautobot/nautobot-plugin-golden-config/tree/develop/docs/dev/dev_adr.md).
