"""Custom exceptions for Containerlab app."""


class GitRepositoryNotFound(Exception):
    """Git repository not found."""

    pass
