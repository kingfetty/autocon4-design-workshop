"""REST API module for containerlab app."""
